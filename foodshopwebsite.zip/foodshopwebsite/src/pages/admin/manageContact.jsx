import React from 'react';
import ContactTable from '../../components/Admin/ContactTable';

const ManageContact = () => {
    return (
        <div className=''>
           <ContactTable/>
        </div>
    );
};

export default ManageContact;