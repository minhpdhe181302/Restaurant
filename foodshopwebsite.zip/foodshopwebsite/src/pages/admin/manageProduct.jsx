import React from 'react';
import TableProduct from '../../components/Admin/TableProduct';

const ManageProduct = () => {
    return (
        <div className=''>
           <TableProduct/>
        </div>
    );
};

export default ManageProduct;